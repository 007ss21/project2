const config = {
  cloud_route: 'index'
}

export { config }