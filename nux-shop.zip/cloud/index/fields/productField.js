//  指定返回结果中记录需返回的字段
module.exports = {
  PRODUCTFIELD: {
    product_name: true,
    product_img: true,
    product_price: true,
    product_sell_price: true,
    product_stock: true,
    product_description:true
  }
}