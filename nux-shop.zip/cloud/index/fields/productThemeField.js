// 指定返回结果中记录需返回的字段
module.exports = {
    PRODUCTTHEMEFIELD: {
       theme_type: true,
       product_theme: true,
       _id: false
    }
  }