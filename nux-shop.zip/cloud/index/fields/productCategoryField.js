// PRODUCT_CATEGORY 指定返回结果中记录需返回的字段
module.exports = {
    PRODUCT_CATEGORY_FIELD: {
      category_name: true,
      category_type: true,
      _id:false
    }
  }