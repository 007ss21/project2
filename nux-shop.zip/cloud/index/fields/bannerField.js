// banner 指定返回结果中记录需返回的字段
module.exports = {
  BANNERFIELD: {
    name: true,
    description: true,
    image: true,
    product_id:true
  }
}