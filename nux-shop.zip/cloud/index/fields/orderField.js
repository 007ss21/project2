// order 指定返回结果中记录需返回的字段
module.exports = {
    ORDERFIELD: {
        buyer_name: true,
        buyer_phone: true,
        buyer_address: true,
        order_amount: true,
        orderdetail: true,
        create_time: true,
        order_status: true
    }
}