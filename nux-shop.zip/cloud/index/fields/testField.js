// 指定返回结果中记录需返回的字段
module.exports = {
  testField: {
    name : true,
    sex:true,
    age : true
  }
}