// 表名
module.exports = {
  BANNER : 'banner',
  THEME  : 'theme',
  PRODUCT: 'product',
  PRODUCT_THEME : 'product_theme',
  PRODUCT_CATEGORY : 'product_category',
  ORDER:"order",
  ORDER_DETAIL:"order_detail"
}